void DelayUs(unsigned long t);

void DHT11_Start();

int DHT11_Check_Response (void);

int DHT11_Read (void);